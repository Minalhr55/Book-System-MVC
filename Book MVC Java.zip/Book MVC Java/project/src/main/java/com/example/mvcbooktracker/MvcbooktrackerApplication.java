package com.example.mvcbooktracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvcbooktrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MvcbooktrackerApplication.class, args);
	}

}

package com.example.mvcbooktracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvcbooktrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
